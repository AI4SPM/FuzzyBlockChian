package com.chentinghao.FastBFT;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/4 22:15
 * description:
 */
import java.util.Random;

public class IntuitionisticFuzzyTrustSystem {
    private static final Random random = new Random();

    public static double getTrustScore() {
        // 生成一个介于0到1之间的随机信任得分
        return random.nextDouble();
    }
}
