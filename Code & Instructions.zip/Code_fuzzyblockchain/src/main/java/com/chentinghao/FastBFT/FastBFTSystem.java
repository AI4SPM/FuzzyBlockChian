package com.chentinghao.FastBFT;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Fast BFT 投票共识系统
 */
public class FastBFTSystem {

    public static void main(String[] args) {
        int totalNodes = 100;       // 总节点数
        int consensusNodes = 20;    // 每轮参与共识的节点数
        int totalRounds = 100;      // 共识轮数
        double thresholdRatio = 2.0 / 3.0; // 共识阈值比例

        FastBFTSystem system = new FastBFTSystem(totalNodes, consensusNodes, totalRounds, thresholdRatio);
        system.runConsensus();
        system.shutdown();
    }

    private final List<Node> nodes = new ArrayList<>();
    private final ExecutorService nodeExecutor;
    private final MessageDispatcher dispatcher;
    private final int totalRounds;
    private final int consensusNodes;
    private final double thresholdRatio;
    private final Random random = new Random();

    /**
     * 构造函数
     *
     * @param totalNodes     总节点数
     * @param consensusNodes 每轮参与共识的节点数
     * @param totalRounds    共识轮数
     * @param thresholdRatio 共识阈值比例
     */
    public FastBFTSystem(int totalNodes, int consensusNodes, int totalRounds, double thresholdRatio) {
        this.consensusNodes = consensusNodes;
        this.totalRounds = totalRounds;
        this.thresholdRatio = thresholdRatio;
        // 创建固定大小的线程池，用于节点处理
        this.nodeExecutor = Executors.newFixedThreadPool(totalNodes);
        // 初始化消息分发器
        this.dispatcher = new MessageDispatcher();
        // 初始化节点
        addNodes(totalNodes);
    }

    /**
     * 添加指定数量的节点到系统中
     *
     * @param count 节点数量
     */
    private void addNodes(int count) {
        for (int i = 1; i <= count; i++) {
            Node node = new Node("Node-" + i, this);
            nodes.add(node);
            nodeExecutor.submit(node);
        }
    }

    /**
     * 运行指定轮数的共识过程
     */
    public void runConsensus() {
        long startTime = System.currentTimeMillis();

        for (int round = 1; round <= totalRounds; round++) {
            System.out.printf("=== 第 %d 轮共识 ===\n", round);
            // 随机选择20个节点参与共识
            List<Node> selectedNodes = selectRandomNodes(consensusNodes);
            System.out.printf("选择的节点: %s\n", getNodeIds(selectedNodes));

            // 选择一个领导者
            Node leader = selectedNodes.get(random.nextInt(consensusNodes));
            String proposal = "Proposal-Round-" + round;
            System.out.printf("领导者 %s 提出提案: %s\n", leader.getId(), proposal);

            // 领导者发送 PRE_PREPARE 消息
            Message prePrepare = new Message(MessageType.PRE_PREPARE, leader.getId(), proposal);
            dispatcher.sendMessage(leader, prePrepare);

            // 等待足够时间让消息传递和处理完成
            // 根据最大延迟 (120ms) 和消息阶段的数量 (PRE_PREPARE -> PREPARE -> COMMIT)
            // 这里假设每个阶段需要等待最多120ms
            try {
                Thread.sleep(480); // 4阶段 * 120ms = 480ms，取近似值
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("共识过程被中断。");
                break;
            }

            // 检查共识结果
            List<Node> committedNodes = getCommittedNodes(proposal, thresholdRatio);
            double agreeVotes = committedNodes.size();
            double threshold = Math.ceil(consensusNodes * thresholdRatio);
            boolean consensus = agreeVotes >= threshold;

            System.out.printf("投票结果: 赞成票=%d, 阈值=%.2f -> %s\n\n",
                    (int) agreeVotes, threshold,
                    consensus ? "达成共识" : "未达成共识");
        }

        long endTime = System.currentTimeMillis();
        double totalSeconds = (endTime - startTime) / 1000.0;
        double averageSeconds = totalSeconds / totalRounds;
        System.out.printf("100轮共识总时间: %.2f秒\n", totalSeconds);
        System.out.printf("平均每轮共识时间: %.2f秒\n", averageSeconds);
    }

    /**
     * 随机选择指定数量的节点
     *
     * @param num 需要选择的节点数
     * @return 选择的节点列表
     */
    private List<Node> selectRandomNodes(int num) {
        List<Node> copy = new ArrayList<>(nodes);
        Collections.shuffle(copy, random);
        return copy.subList(0, num);
    }

    /**
     * 获取节点ID的字符串表示
     *
     * @param nodes 节点列表
     * @return 节点ID的逗号分隔字符串
     */
    private String getNodeIds(List<Node> nodes) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < nodes.size(); i++) {
            sb.append(nodes.get(i).getId());
            if (i < nodes.size() - 1) {
                sb.append(", ");
            }
        }
        return sb.toString();
    }

    /**
     * 获取已提交的节点列表
     *
     * @param proposal      提案内容
     * @param thresholdRatio 阈值比例
     * @return 已提交的节点列表
     */
    private List<Node> getCommittedNodes(String proposal, double thresholdRatio) {
        // 统计接收到 COMMIT 消息的节点
        List<Node> committedNodes = dispatcher.getCommittedNodes(proposal);
        double threshold = Math.ceil(consensusNodes * thresholdRatio);
        if (committedNodes.size() >= threshold) {
            return committedNodes;
        } else {
            return Collections.emptyList();
        }
    }

    /**
     * 关闭线程池和消息分发器
     */
    public void shutdown() {
        dispatcher.shutdown();
        nodeExecutor.shutdownNow();
        try {
            if (!nodeExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
                nodeExecutor.shutdownNow();
                if (!nodeExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
                    System.err.println("线程池未能正常关闭。");
                }
            }
        } catch (InterruptedException ie) {
            nodeExecutor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    /**
     * 节点类，表示一个参与共识的节点
     */
    static class Node implements Runnable {
        private final String id;
        private final FastBFTSystem system;
        private final BlockingQueue<Message> messageQueue;
        private final AtomicBoolean hasVoted;
        private final Random random = new Random();

        public Node(String id, FastBFTSystem system) {
            this.id = id;
            this.system = system;
            this.messageQueue = new LinkedBlockingQueue<>();
            this.hasVoted = new AtomicBoolean(false);
        }

        public String getId() {
            return id;
        }

        /**
         * 接收消息
         *
         * @param message 接收到的消息
         */
        public void receiveMessage(Message message) {
            messageQueue.offer(message);
        }

        /**
         * 处理消息
         *
         * @param message 要处理的消息
         */
        private void handleMessage(Message message) {
            switch (message.getType()) {
                case PRE_PREPARE:
                    handlePrePrepare(message);
                    break;
                case PREPARE:
                    handlePrepare(message);
                    break;
                case COMMIT:
                    handleCommit(message);
                    break;
                default:
                    // 处理其他消息类型（如 VOTE）
                    break;
            }
        }

        private void handlePrePrepare(Message message) {
            if (hasVoted.compareAndSet(false, true)) {
                // 发送 PREPARE 消息
                Message prepare = new Message(MessageType.PREPARE, id, message.getProposal());
                system.dispatcher.sendMessage(this, prepare);
            }
        }

        private void handlePrepare(Message message) {
            if (hasVoted.compareAndSet(false, true)) {
                // 发送 COMMIT 消息
                Message commit = new Message(MessageType.COMMIT, id, message.getProposal());
                system.dispatcher.sendMessage(this, commit);
            }
        }

        private void handleCommit(Message message) {
            // 记录 COMMIT 消息
            system.dispatcher.recordCommit(message.getProposal(), this);
        }

        /**
         * 模拟通信延迟并处理消息
         */
        @Override
        public void run() {
            try {
                while (true) {
                    Message message = messageQueue.take();
                    handleMessage(message);
                }
            } catch (InterruptedException e) {
                System.out.println(id + " 节点停止运行。");
            }
        }
    }

    /**
     * 消息类型枚举
     */
    enum MessageType {
        PRE_PREPARE,
        PREPARE,
        COMMIT,
        VOTE
    }

    /**
     * 消息类，用于节点之间传递信息
     */
    static class Message {
        private final MessageType type;
        private final String senderId;
        private final String proposal;

        public Message(MessageType type, String senderId, String proposal) {
            this.type = type;
            this.senderId = senderId;
            this.proposal = proposal;
        }

        public MessageType getType() {
            return type;
        }

        public String getSenderId() {
            return senderId;
        }

        public String getProposal() {
            return proposal;
        }
    }

    /**
     * 消息分发器类，负责在模拟网络中传递消息，并在传递过程中添加延迟
     */
    static class MessageDispatcher {
        private final ExecutorService dispatcherExecutor;
        private final Map<String, List<Node>> commitRecords;
        private final Random random = new Random();

        public MessageDispatcher() {
            this.dispatcherExecutor = Executors.newCachedThreadPool();
            this.commitRecords = new ConcurrentHashMap<>();
        }

        /**
         * 发送消息给所有节点，除发送者本身
         *
         * @param sender 发送消息的节点
         * @param message 要发送的消息
         */
        public void sendMessage(Node sender, Message message) {
            for (Node node : sender.system.nodes) {
                if (!node.getId().equals(sender.getId())) {
                    dispatcherExecutor.submit(() -> deliverMessage(node, message));
                }
            }
        }

        /**
         * 模拟消息传递的延迟并将消息传递给目标节点
         *
         * @param node    目标节点
         * @param message 要传递的消息
         */
        private void deliverMessage(Node node, Message message) {
            // 模拟通信延迟
            int delay = 20 + random.nextInt(101); // 20ms到120ms
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("消息传递被中断。");
                return;
            }
            node.receiveMessage(message);
        }

        /**
         * 记录 COMMIT 消息
         *
         * @param proposal 提案内容
         * @param node     发送 COMMIT 消息的节点
         */
        public void recordCommit(String proposal, Node node) {
            commitRecords.computeIfAbsent(proposal, k -> Collections.synchronizedList(new ArrayList<>())).add(node);
        }

        /**
         * 获取已提交的节点列表
         *
         * @param proposal 提案内容
         * @return 已提交的节点列表
         */
        public List<Node> getCommittedNodes(String proposal) {
            return commitRecords.getOrDefault(proposal, Collections.emptyList());
        }

        /**
         * 关闭消息分发器的线程池
         */
        public void shutdown() {
            dispatcherExecutor.shutdownNow();
            try {
                if (!dispatcherExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
                    dispatcherExecutor.shutdownNow();
                    if (!dispatcherExecutor.awaitTermination(60, TimeUnit.SECONDS)) {
                        System.err.println("消息分发器线程池未能正常关闭。");
                    }
                }
            } catch (InterruptedException ie) {
                dispatcherExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
