//package com.chentinghao.FastBFT;
//
///**
// * @Auther Chen Tinghao
// * @Date 2025/1/4 22:14
// * description:
// */
//import java.util.concurrent.BlockingQueue;
//import java.util.concurrent.LinkedBlockingQueue;
//import java.util.concurrent.atomic.AtomicBoolean;
//import java.util.Random;
//
//public class Node implements Runnable {
//    private final String id;
//    private final BlockingQueue<Message> messageQueue;
//    private final FastBFTSystem system;
//    private final double trustScore;
//    private final AtomicBoolean hasVoted;
//    private static final Random random = new Random();
//
//    public Node(String id, FastBFTSystem system) {
//        this.id = id;
//        this.system = system;
//        this.messageQueue = new LinkedBlockingQueue<>();
//        this.trustScore = IntuitionisticFuzzyTrustSystem.getTrustScore();
//        this.hasVoted = new AtomicBoolean(false);
//    }
//
//    public String getId() {
//        return id;
//    }
//
//    public double getTrustScore() {
//        return trustScore;
//    }
//
//    public void receiveMessage(Message message) {
//        messageQueue.offer(message);
//    }
//
//    @Override
//    public void run() {
//        try {
//            while (true) {
//                Message message = messageQueue.take();
//                handleMessage(message);
//            }
//        } catch (InterruptedException e) {
//            System.out.println(id + " 节点停止运行。");
//        }
//    }
//
//    private void handleMessage(Message message) {
//        switch (message.getType()) {
//            case PRE_PREPARE:
//                handlePrePrepare(message);
//                break;
//            case PREPARE:
//                handlePrepare(message);
//                break;
//            case COMMIT:
//                handleCommit(message);
//                break;
//            default:
//                // 处理其他消息类型（如VOTE）
//                break;
//        }
//    }
//
//    private void handlePrePrepare(Message message) {
//        if (!hasVoted.getAndSet(true)) {
//            // 发送 PREPARE 消息
//            Message prepare = new Message(MessageType.PREPARE, id, message.getProposal());
//            system.broadcastMessage(prepare, id);
//        }
//    }
//
//    private void handlePrepare(Message message) {
//        if (!hasVoted.getAndSet(true)) {
//            // 发送 COMMIT 消息
//            Message commit = new Message(MessageType.COMMIT, id, message.getProposal());
//            system.broadcastMessage(commit, id);
//        }
//    }
//
//    private void handleCommit(Message message) {
//        // 在收到足够数量的 COMMIT 消息后，达成共识
//        system.recordCommit(message.getProposal(), this);
//    }
//
//    // 模拟通信延迟
//    public void communicate() {
//        int delay = 20 + random.nextInt(101); // 20ms到120ms
//        try {
//            Thread.sleep(delay);
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//            System.err.println(id + " 通信被中断。");
//        }
//    }
//}
