package com.chentinghao.FastBFT;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/4 22:14
 * description:
 */
import java.io.Serializable;

public class Message implements Serializable {
    private final MessageType type;
    private final String senderId;
    private final String proposal;

    public Message(MessageType type, String senderId, String proposal) {
        this.type = type;
        this.senderId = senderId;
        this.proposal = proposal;
    }

    public MessageType getType() {
        return type;
    }

    public String getSenderId() {
        return senderId;
    }

    public String getProposal() {
        return proposal;
    }
}
