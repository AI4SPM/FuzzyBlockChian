package com.chentinghao.FastBFT;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/4 22:14
 * description:
 */
public enum MessageType {
    PRE_PREPARE,
    PREPARE,
    COMMIT,
    VOTE
}
