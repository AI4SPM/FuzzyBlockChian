//package com.chentinghao.simpleExample;
//
//import com.chentinghao.Node;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//
///**
// * @Auther Chen Tinghao
// * @Date 2024/12/21 12:51
// * description:
// */
//public class ConsensusSimulation {
//    private List<Node> nodes = new ArrayList<>();
//    private ExecutorService executor = Executors.newCachedThreadPool();
//
//    public void setupNodes(int count) {
//        for (int i = 0; i < count; i++) {
//            nodes.add(new Node(i));
//        }
//    }
//
//    public void sendMessage(int from, int to, String message) {
//        System.out.println("Sending message from Node " + from + " to Node " + to);
//        nodes.get(to).receiveMessage(message);
//    }
//
//    public void simulate() {
//        for (Node node : nodes) {
//            executor.submit(() -> node.processMessages());
//        }
//        executor.shutdown();
//    }
//
//    public static void main(String[] args) {
//        ConsensusSimulation simulation = new ConsensusSimulation();
//        simulation.setupNodes(5);
//        simulation.sendMessage(0, 1, "Hello from Node 0");
//        simulation.sendMessage(1, 2, "Hello from Node 1");
//        simulation.simulate();
//    }
//
//}
