package com.chentinghao.HotStuff;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/2 14:17
 * description:
 */
class Blockchain {
    private List<Block> chain;

    public Blockchain() {
        chain = new ArrayList<>();
        chain.add(new Block("Genesis", null, "Genesis")); // 创世区块
    }

    public Block getLastBlock() {
        return chain.get(chain.size() - 1);
    }

    public void addBlock(Block block) {
        chain.add(block);
    }

    public void printChain() {
        for (Block block : chain) {
            System.out.println(block.getBlockId());
        }
    }
}

//class Blockchain {
//    private List<Block> chain;
//
//    public Blockchain() {
//        chain = new ArrayList<>();
//        // 添加创世区块
//        chain.add(new Block("Genesis", null, "Genesis"));
//    }
//
//    public void addBlock(Block block) {
//        chain.add(block);
//    }
//
//    public List<Block> getChain() {
//        return chain;
//    }
//
//    public Block getLastBlock() {
//        return chain.get(chain.size() - 1);
//    }
//
//    public void printChain() {
//        for (Block block : chain) {
//            System.out.println(block);
//        }
//    }
//}
