package com.chentinghao.HotStuff;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/2 14:33
 * description:
 */
public class HotStuffSimulationWithDelay {
    public static void main(String[] args) {
        int nodeCount = 18; // 节点数量
        int rounds = 100;   // 共识轮数

        HotStuffConsensusWithDelay consensus = new HotStuffConsensusWithDelay(nodeCount);
        long totalTime = consensus.executeConsensus(rounds);
        System.out.printf("100次共识总时间: %.2f秒\n", totalTime / 1000.0);
        System.out.printf("平均每次共识时间: %.2f秒\n", totalTime / 1000.0 / 100);

    }
}
