package com.chentinghao.HotStuff;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/2 14:17
 * description:
 */
//class Block {
//    private String blockId;
//    private String previousBlockId;
//    private String phase; // 当前区块的阶段 (Prepare, Pre-commit, Commit)
//
//    public Block(String blockId, String previousBlockId, String phase) {
//        this.blockId = blockId;
//        this.previousBlockId = previousBlockId;
//        this.phase = phase;
//    }
//
//    public String getBlockId() {
//        return blockId;
//    }
//
//    public String getPreviousBlockId() {
//        return previousBlockId;
//    }
//
//    public String getPhase() {
//        return phase;
//    }
//
//    @Override
//    public String toString() {
//        return "Block{" +
//                "blockId='" + blockId + '\'' +
//                ", previousBlockId='" + previousBlockId + '\'' +
//                ", phase='" + phase + '\'' +
//                '}';
//    }
//}
class Block {
    private String blockId;
    private String previousBlockId;
    private String phase;

    public Block(String blockId, String previousBlockId, String phase) {
        this.blockId = blockId;
        this.previousBlockId = previousBlockId;
        this.phase = phase;
    }

    public String getBlockId() {
        return blockId;
    }
}
