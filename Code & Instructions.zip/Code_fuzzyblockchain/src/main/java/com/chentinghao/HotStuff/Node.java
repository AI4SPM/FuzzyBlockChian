package com.chentinghao.HotStuff;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/2 14:14
 * description:
 */
//class Node {
//    private int id; // 节点ID
//    private boolean isLeader; // 是否为Leader
//
//    public Node(int id) {
//        this.id = id;
//        this.isLeader = false;
//    }
//
//    public int getId() {
//        return id;
//    }
//
//    public boolean isLeader() {
//        return isLeader;
//    }
//
//    public void setLeader(boolean leader) {
//        isLeader = leader;
//    }
//
//    // 模拟节点投票
//    public boolean vote(String block) {
//        // 简单模拟节点验证区块的合法性
//        return new Random().nextInt(100) > 5; // 95% 几率同意
//    }
//    public boolean voteWithDelay(String blockId, int delay) {
//        try {
//            Thread.sleep(delay); // 模拟通信延迟
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//        return new Random().nextInt(100) > 5; // 95% 几率投票成功
//    }
//
//}
class Node {
    private int id;
    private boolean isLeader;

    public Node(int id) {
        this.id = id;
        this.isLeader = false;
    }

    public int getId() {
        return id;
    }

    public void setLeader(boolean leader) {
        isLeader = leader;
    }

    // 节点投票，返回 true 表示赞成，false 表示反对
    public boolean vote(String blockId, int delay) {
        try {
            Thread.sleep(delay); // 模拟通信延迟
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Random random = new Random();
        boolean agree = random.nextBoolean(); // 随机赞成或反对
        System.out.printf("Node %d voted %s for block %s (Delay=%dms)\n",
                id, agree ? "AGREE" : "DISAGREE", blockId, delay);
        return agree;
    }
}
