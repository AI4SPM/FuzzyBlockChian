//package com.chentinghao.HotStuff.yuanshi;
//
//import com.chentinghao.HotStuff.Node;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.stream.Collectors;
//
///**
// * @Auther Chen Tinghao
// * @Date 2025/1/2 14:15
// * description:
// */
//class HotStuffConsensus {
//    private List<Node> nodes;
//    private Node leader;
//
//    public HotStuffConsensus(int nodeCount) {
//        nodes = new ArrayList<>();
//        for (int i = 0; i < nodeCount; i++) {
//            nodes.add(new Node(i));
//        }
//        // 默认第一个节点为初始领导者
//        leader = nodes.get(0);
//        leader.setLeader(true);
//    }
//
//    public void executeConsensus(int rounds) {
//        for (int i = 0; i < rounds; i++) {
//            System.out.println("Round " + (i + 1) + " started:");
//            boolean success = performConsensus("Block_" + (i + 1));
//            if (!success) {
//                System.out.println("Consensus failed in Round " + (i + 1));
//            } else {
//                System.out.println("Consensus succeeded in Round " + (i + 1));
//            }
//            System.out.println();
//        }
//    }
//
//    private boolean performConsensus(String block) {
//        System.out.println("Leader " + leader.getId() + " proposed: " + block);
//
//        // 1. Prepare阶段：收集准备投票
//        List<Node> preparedNodes = nodes.stream()
//                .filter(node -> node.vote(block))
//                .collect(Collectors.toList());
//        if (preparedNodes.size() < (2 * nodes.size() / 3)) {
//            System.out.println("Prepare phase failed. Votes: " + preparedNodes.size());
//            switchLeader();
//            return false;
//        }
//        System.out.println("Prepare phase succeeded. Votes: " + preparedNodes.size());
//
//        // 2. Pre-commit阶段
//        List<Node> preCommittedNodes = preparedNodes.stream()
//                .filter(node -> node.vote(block))
//                .collect(Collectors.toList());
//        if (preCommittedNodes.size() < (2 * nodes.size() / 3)) {
//            System.out.println("Pre-commit phase failed. Votes: " + preCommittedNodes.size());
//            switchLeader();
//            return false;
//        }
//        System.out.println("Pre-commit phase succeeded. Votes: " + preCommittedNodes.size());
//
//        // 3. Commit阶段
//        List<Node> committedNodes = preCommittedNodes.stream()
//                .filter(node -> node.vote(block))
//                .collect(Collectors.toList());
//        if (committedNodes.size() < (2 * nodes.size() / 3)) {
//            System.out.println("Commit phase failed. Votes: " + committedNodes.size());
//            switchLeader();
//            return false;
//        }
//        System.out.println("Commit phase succeeded. Votes: " + committedNodes.size());
//
//        // 4. Decide阶段
//        System.out.println("Decide phase: Block " + block + " committed!");
//        return true;
//    }
//
//    // 切换领导者
//    private void switchLeader() {
//        System.out.println("Switching leader...");
//        int currentLeaderId = leader.getId();
//        leader.setLeader(false);
//        leader = nodes.get((currentLeaderId + 1) % nodes.size());
//        leader.setLeader(true);
//        System.out.println("New leader is Node " + leader.getId());
//    }
//}
