//package com.chentinghao.HotStuff.yuanshi;
//
//import com.chentinghao.HotStuff.Block;
//import com.chentinghao.HotStuff.Blockchain;
//import com.chentinghao.HotStuff.Node;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.stream.Collectors;
//
///**
// * @Auther Chen Tinghao
// * @Date 2025/1/2 14:17
// * description:
// */
//class HotStuffConsensusWithBlocks {
//    private List<Node> nodes;
//    private Node leader;
//    private Blockchain blockchain;
//
//    public HotStuffConsensusWithBlocks(int nodeCount) {
//        nodes = new ArrayList<>();
//        for (int i = 0; i < nodeCount; i++) {
//            nodes.add(new Node(i));
//        }
//        leader = nodes.get(0);
//        leader.setLeader(true);
//        blockchain = new Blockchain();
//    }
//
//    public void executeConsensus(int rounds) {
//        for (int i = 0; i < rounds; i++) {
//            System.out.println("Round " + (i + 1) + " started:");
//            performConsensus("Block_" + (i + 1));
//            System.out.println("Current Blockchain:");
//            blockchain.printChain();
//            System.out.println();
//        }
//    }
//
//    private void performConsensus(String blockId) {
//        Block lastBlock = blockchain.getLastBlock();
//
//        // Prepare阶段
//        Block prepareBlock = new Block(blockId + "_Prepare", lastBlock.getBlockId(), "Prepare");
//        if (!collectVotes(prepareBlock)) {
//            switchLeader();
//            return;
//        }
//        blockchain.addBlock(prepareBlock);
//        System.out.println("Prepare phase succeeded.");
//
//        // Pre-commit阶段
//        Block preCommitBlock = new Block(blockId + "_Pre-commit", prepareBlock.getBlockId(), "Pre-commit");
//        if (!collectVotes(preCommitBlock)) {
//            switchLeader();
//            return;
//        }
//        blockchain.addBlock(preCommitBlock);
//        System.out.println("Pre-commit phase succeeded.");
//
//        // Commit阶段
//        Block commitBlock = new Block(blockId + "_Commit", preCommitBlock.getBlockId(), "Commit");
//        if (!collectVotes(commitBlock)) {
//            switchLeader();
//            return;
//        }
//        blockchain.addBlock(commitBlock);
//        System.out.println("Commit phase succeeded.");
//
//        // Decide阶段
//        System.out.println("Decide phase: Block " + blockId + " fully committed!");
//    }
//
//    private boolean collectVotes(Block block) {
//        List<Node> votedNodes = nodes.stream()
//                .filter(node -> node.vote(block.getBlockId()))
//                .collect(Collectors.toList());
//        return votedNodes.size() >= (2 * nodes.size() / 3);
//    }
//
//    private void switchLeader() {
//        System.out.println("Switching leader...");
//        int currentLeaderId = leader.getId();
//        leader.setLeader(false);
//        leader = nodes.get((currentLeaderId + 1) % nodes.size());
//        leader.setLeader(true);
//        System.out.println("New leader is Node " + leader.getId());
//    }
//}
