package com.chentinghao.HotStuff;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

// HotStuff共识系统
public class HotStuffConsensusWithDelay {
    private final List<Node> nodes;
    private Node leader;
    private final Blockchain blockchain;
    private final Random random;

    public HotStuffConsensusWithDelay(int nodeCount) {
        nodes = new ArrayList<>();
        for (int i = 0; i < nodeCount; i++) {
            nodes.add(new Node(i));
        }
        leader = nodes.get(0);
        leader.setLeader(true);
        blockchain = new Blockchain();
        random = new Random();
    }

    /**
     * Executes multiple rounds of consensus and returns the total execution time.
     *
     * @param rounds The number of rounds to execute.
     * @return Total execution time in milliseconds.
     */
    public long executeConsensus(int rounds) {
        long totalStartTime = System.currentTimeMillis(); // Start time

        for (int i = 0; i < rounds; i++) {
            long roundStartTime = System.currentTimeMillis();
            System.out.println("Round " + (i + 1) + " started:");
            performConsensus("Block_" + (i + 1));

            long roundEndTime = System.currentTimeMillis();
            System.out.printf("Round %d completed in %d ms\n\n", i + 1, (roundEndTime - roundStartTime));
        }

        long totalEndTime = System.currentTimeMillis(); // End time
        System.out.printf("Total time for %d rounds: %d ms\n", rounds, (totalEndTime - totalStartTime));
        System.out.printf("Average time per round: %.2f ms\n", (totalEndTime - totalStartTime) / (double) rounds);

        return totalEndTime - totalStartTime;
    }

    /**
     * Performs a single round of consensus for a given block.
     *
     * @param blockId The ID of the block to reach consensus on.
     */
    private void performConsensus(String blockId) {
        Block lastBlock = blockchain.getLastBlock();

        // Prepare phase
        Block prepareBlock = new Block(blockId + "_Prepare", lastBlock.getBlockId(), "Prepare");
        addCommunicationDelay("Prepare phase communication delay");
        if (!collectVotes(prepareBlock)) {
            switchLeader();
            return;
        }
        blockchain.addBlock(prepareBlock);
        System.out.println("Prepare phase succeeded.");

        // Pre-commit phase
        Block preCommitBlock = new Block(blockId + "_Pre-commit", prepareBlock.getBlockId(), "Pre-commit");
        addCommunicationDelay("Pre-commit phase communication delay");
        if (!collectVotes(preCommitBlock)) {
            switchLeader();
            return;
        }
        blockchain.addBlock(preCommitBlock);
        System.out.println("Pre-commit phase succeeded.");

        // Commit phase
        Block commitBlock = new Block(blockId + "_Commit", preCommitBlock.getBlockId(), "Commit");
        addCommunicationDelay("Commit phase communication delay");
        if (!collectVotes(commitBlock)) {
            switchLeader();
            return;
        }
        blockchain.addBlock(commitBlock);
        System.out.println("Commit phase succeeded.");

        // Decide phase
        addCommunicationDelay("Decide phase communication delay");
        System.out.println("Decide phase: Block " + blockId + " fully committed!");
    }

    /**
     * Collects votes from all nodes for a given block.
     *
     * @param block The block to be voted on.
     * @return True if the required number of votes is achieved, otherwise false.
     */
    private boolean collectVotes(Block block) {
        ExecutorService executor = Executors.newCachedThreadPool();
        List<Future<Boolean>> futures = new ArrayList<>();

        // Request votes from all nodes with a random delay
        for (Node node : nodes) {
            int delay = 20 + random.nextInt(101); // Random delay: 20ms to 120ms
            futures.add(executor.submit(() -> node.vote(block.getBlockId(), delay)));
        }

        executor.shutdown();

        // Collect votes
        int votes = 0;
        try {
            for (Future<Boolean> future : futures) {
                if (future.get()) {
                    votes++;
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        System.out.printf("Votes collected: %d/%d for block %s\n", votes, nodes.size(), block.getBlockId());
        return votes >= (2 * nodes.size() / 3); // At least 2/3 majority required
    }

    /**
     * Switches the leader to the next node in the list.
     */
    private void switchLeader() {
        addCommunicationDelay("Leader switch communication delay");
        System.out.println("Switching leader...");
        int currentLeaderId = leader.getId();
        leader.setLeader(false);
        leader = nodes.get((currentLeaderId + 1) % nodes.size());
        leader.setLeader(true);
        System.out.println("New leader is Node " + leader.getId());
    }

    /**
     * Adds a random communication delay and logs the delay.
     *
     * @param message A message to indicate where the delay is added.
     */
    private void addCommunicationDelay(String message) {
        int delay = 20 + random.nextInt(101); // Random delay: 20ms to 120ms
        try {
            Thread.sleep(delay); // Simulate communication delay
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("%s (Delay=%dms)\n", message, delay);
    }
}
