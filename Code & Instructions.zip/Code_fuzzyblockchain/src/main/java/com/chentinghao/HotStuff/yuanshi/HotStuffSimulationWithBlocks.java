//package com.chentinghao.HotStuff.yuanshi;
//
//import com.chentinghao.HotStuff.yuanshi.HotStuffConsensusWithBlocks;
//
///**
// * @Auther Chen Tinghao
// * @Date 2025/1/2 14:17
// * description:
// */
//public class HotStuffSimulationWithBlocks {
//    public static void main(String[] args) {
//        int nodeCount = 60; // 节点数量
//        int rounds = 50;   // 共识轮数
//
//        HotStuffConsensusWithBlocks consensus = new HotStuffConsensusWithBlocks(nodeCount);
//        consensus.executeConsensus(rounds);
//    }
//}
