//package com.chentinghao.HotStuff;
//
//import com.chentinghao.HotStuff.yuanshi.HotStuffConsensus;
//
///**
// * @Auther Chen Tinghao
// * @Date 2025/1/2 14:15
// * description:
// */
//public class HotStuffSimulation {
//    public static void main(String[] args) {
//        int nodeCount = 5; // 节点数量
//        int rounds = 50;   // 共识轮数
//
//        HotStuffConsensus consensus = new HotStuffConsensus(nodeCount);
//        consensus.executeConsensus(rounds);
//    }
//}
