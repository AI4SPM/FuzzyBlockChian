package com.chentinghao.Ratf;

/**
 * @author ChenTinghao
 * @Description TODO
 * @package com.chentinghao.Ratf
 * @Created 2025/3/2
 */
import java.util.*;
import java.util.concurrent.*;

public class RaftConsensusSimulation {

    // 模拟网络延迟（20ms到120ms之间）
    private static final Random random = new Random();
    private static final int NUM_NODES = 5; // Raft 的节点数（奇数个）
    private static final int NUM_ITERATIONS = 100; // 执行共识的轮次

    // Raft 选举超时时间（模拟选举阶段）
    private static long getElectionTimeout() {
        return 150 + random.nextInt(151); // 返回150ms到300ms之间
    }

    // 模拟网络延迟（日志复制、心跳等）
    private static long getNetworkDelay() {
        return 20 + random.nextInt(101); // 20ms到120ms之间
    }

    // 执行 Raft 的一次共识轮次（包括选举 + 日志复制）
    private static long performRaftConsensusRound(int round) {
        // 选举时间（Leader 选举过程）
        long electionTime = getElectionTimeout();

        // 日志复制时间（Leader 将日志复制到 Follower）
        List<Long> replicationDelays = new ArrayList<>();
        for (int i = 0; i < NUM_NODES - 1; i++) { // 除了 Leader 外的所有 Follower
            replicationDelays.add(getNetworkDelay());
        }

        // 取所有 Follower 之间的最大日志复制时间（因为需要等所有节点完成复制）
        long maxReplicationTime = Collections.max(replicationDelays);

        // 计算本轮共识时间
        long totalConsensusTime = electionTime + maxReplicationTime;
        System.out.println("Round " + round + ": Election time = " + electionTime + " ms, Log Replication time = "
                + maxReplicationTime + " ms, Total time = " + totalConsensusTime + " ms");

        return totalConsensusTime;
    }

    // 运行 100 轮 Raft 共识模拟
    public static long runRaftConsensusSimulation() throws InterruptedException, ExecutionException {
        ExecutorService executorService = Executors.newFixedThreadPool(NUM_NODES);
        List<Callable<Long>> tasks = new ArrayList<>();

        // 创建共识任务
        for (int i = 0; i < NUM_ITERATIONS; i++) {
            int round = i + 1;
            tasks.add(() -> performRaftConsensusRound(round));
        }

        // 并行执行任务并获取结果
        List<Future<Long>> results = executorService.invokeAll(tasks);
        executorService.shutdown();

        // 计算总共识时间
        long totalConsensusTime = 0;
        for (Future<Long> result : results) {
            totalConsensusTime += result.get();
        }

        return totalConsensusTime;
    }

    public static void main(String[] args) {
        try {
            long totalConsensusTime = runRaftConsensusSimulation();
            System.out.println("Total consensus time for 100 rounds (Raft): " + totalConsensusTime + " ms");
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
