package com.chentinghao.Fuzzy;
import org.apache.commons.math3.distribution.BetaDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.linear.CholeskyDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;

import java.util.Random;

public class GaussianCopula {
    private double correlation;
    private RealMatrix choleskyLower;
    private NormalDistribution standardNormal;

    /**
     * 构造函数，接受相关系数并计算Cholesky分解矩阵。
     *
     * @param correlation 两个变量之间的相关系数（负值表示负相关）
     */
    public GaussianCopula(double correlation) {
        this.correlation = correlation;
        this.standardNormal = new NormalDistribution();
        computeCholesky();
    }

    /**
     * 计算协方差矩阵的Cholesky分解。
     */
    private void computeCholesky() {
        double[][] covMatrix = {
                {1.0, correlation},
                {correlation, 1.0}
        };
        RealMatrix matrix = MatrixUtils.createRealMatrix(covMatrix);
        CholeskyDecomposition cholesky = new CholeskyDecomposition(matrix);
        this.choleskyLower = cholesky.getL();
    }

    /**
     * 生成相关的标准正态随机变量。
     *
     * @param nSamples        生成样本的数量
     * @param randomGenerator 随机数生成器
     * @return 二维数组，第一列和第二列分别为两个相关的标准正态变量
     */
    public double[][] generateCorrelatedNormals(int nSamples, Random randomGenerator) {
        double[][] samples = new double[nSamples][2];

        for (int i = 0; i < nSamples; i++) {
            // 生成独立的标准正态随机数
            double z1 = standardNormal.inverseCumulativeProbability(randomGenerator.nextDouble());
            double z2 = standardNormal.inverseCumulativeProbability(randomGenerator.nextDouble());

            // 通过Cholesky矩阵引入相关性
            double correlated1 = choleskyLower.getEntry(0, 0) * z1 + choleskyLower.getEntry(0, 1) * z2;
            double correlated2 = choleskyLower.getEntry(1, 0) * z1 + choleskyLower.getEntry(1, 1) * z2;

            samples[i][0] = correlated1;
            samples[i][1] = correlated2;
        }

        return samples;
    }

    /**
     * 获取标准正态分布对象。
     *
     * @return 标准正态分布对象
     */
    public NormalDistribution getStandardNormal() {
        return standardNormal;
    }
}
