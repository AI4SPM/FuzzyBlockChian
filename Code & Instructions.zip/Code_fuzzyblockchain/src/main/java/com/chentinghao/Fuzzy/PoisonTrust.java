package com.chentinghao.Fuzzy;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author ChenTinghao
 * @Description TODO
 * @package com.chentinghao.Fuzzy
 * @Created 2025/3/2
 */

public class PoisonTrust {
    // 节点的信任值
    private double trustValue;
    // 成功和失败的交互次数
    private int successfulInteractions;
    private int unsuccessfulInteractions;
    // 泊松分布参数（交互的平均率）
    private final double lambda;

    // 构造函数：初始化信任值和交互计数
    public PoisonTrust() {
        this.trustValue = 0.5; // 初始信任值设为0.5
        this.successfulInteractions = 0;
        this.unsuccessfulInteractions = 0;
        this.lambda = 1.0; // 假设平均交互率为1，可以根据实际情况调整
    }

    // 更新信任值的方法，参数 success 为 true 表示交互成功，false 表示交互失败
    public void updateTrust(boolean success) {
        if (success) {
            successfulInteractions++;
        } else {
            unsuccessfulInteractions++;
        }
        // 根据泊松分布公式计算更新后的信任值
        double p = calculatePoisson(successfulInteractions, unsuccessfulInteractions);
        trustValue = p;
    }

    // 使用对数泊松分布公式计算信任值
    private double calculatePoisson(int a, int b) {
        int totalInteractions = a + b;

        // 避免除以0错误
        if (totalInteractions == 0) {
            return 0.5; // 如果没有交互，返回初始信任值
        }

        double rateOfCooperation = (double) a / totalInteractions;
        // 调整 lambda 的计算方式
        double lambda = rateOfCooperation; //  lambda = rateOfCooperation;

        // 使用对数泊松分布公式
        double logPoissonValue = -lambda + a * Math.log(lambda) - logFactorial(a);

        // 将对数结果转换回普通数值
        double poissonValue = Math.exp(logPoissonValue);

        // 调整归一化方式 (使用 Sigmoid 函数)
        double normalizedTrust = 1.0 / (1.0 + Math.exp(-poissonValue)+0.01); //调整了sigmoid函数的参数

        return normalizedTrust;
    }

    // 辅助方法：计算对数阶乘
    private double logFactorial(int n) {
        if (n <= 1) return 0;
        double result = 0;
        for (int i = 2; i <= n; i++) {
            result += Math.log(i);
        }
        return result;
    }

    // 获取当前的信任值
    public double getTrustValue() {
        return trustValue;
    }

    // 主函数：仿真测试
    public static void main(String[] args) {
        // simulation
        int numberOfNodes = 10; //节点数
        List<TrustResult> trustResults = generateTrustResults(numberOfNodes);
        for (int i = 0; i < trustResults.size(); i++) {
            TrustResult result = trustResults.get(i);
            System.out.println("Node " + i + ": Trust Score = " + result.getFinalTrustScore() +
                    ", Spatial-Temporal Value = " + result.getSpatialTemporalValue());
        }
    }

    public static List<TrustResult> generateTrustResults(int numberOfNodes) {
        List<TrustResult> trustResults = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < numberOfNodes; i++) {
            PoisonTrust nodeTrust = new PoisonTrust();

            // 1. 随机生成总交互次数 (服从正态分布，均值50，标准差15)
            int totalInteractions = (int) Math.round(random.nextGaussian() * 15 + 50);

            // 确保 totalInteractions 在 0-100 之间
            totalInteractions = Math.max(0, Math.min(100, totalInteractions));


            // 2. 随机生成每次交互的行为 (调用 updateTrust)
            for (int j = 0; j < totalInteractions; j++) {
                boolean success = random.nextBoolean(); // 随机决定是信任还是恶意行为
                nodeTrust.updateTrust(success);
            }
            double spatialTemporalValue = random.nextDouble();
            trustResults.add(new TrustResult(nodeTrust.getTrustValue(), spatialTemporalValue));
        }
        return trustResults;
    }
}
