package com.chentinghao.Fuzzy;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/2 15:11
 * description:
 */
import java.util.Random;

import java.util.Random;

public class FuzzyTrustSystem {

    public static void main(String[] args) {
        // 随机生成输入因子值（均在[0,1]范围内）
        double trustBehavior = generateRandomFactor();
        double maliciousBehavior = generateRandomFactor();
        double spatialDistance = generateRandomFactor();
        double trajectorySimilarity = generateRandomFactor();

        System.out.println("随机生成的因子值（均在[0,1]范围内）：");
        System.out.printf("信任行为: %.2f%n", trustBehavior);
        System.out.printf("恶意行为: %.2f%n", maliciousBehavior);
        System.out.printf("时空距离: %.2f%n", spatialDistance);
        System.out.printf("轨迹重合性: %.2f%n", trajectorySimilarity);

        // 隶属度计算（梯形隶属度带重叠）
        double[] trustMembership = calculateOverlappingMembership(trustBehavior, new double[][]{
                {0.0, 0.0, 0.2, 0.4},  // F1
                {0.2, 0.4, 0.4, 0.6},  // F2
                {0.4, 0.6, 0.6, 0.8},  // F3
                {0.6, 0.8, 0.8, 1.0},  // F4
                {0.8, 1.0, 1.0, 1.0}   // F5
        });
        double[] maliciousMembership = calculateOverlappingMembership(maliciousBehavior, new double[][]{
                {0.0, 0.0, 0.2, 0.4},  // F1
                {0.2, 0.4, 0.4, 0.6},  // F2
                {0.4, 0.6, 0.6, 0.8},  // F3
                {0.6, 0.8, 0.8, 1.0},  // F4
                {0.8, 1.0, 1.0, 1.0}   // F5
        });
        double[] spatialMembership = calculateOverlappingMembership(spatialDistance, new double[][]{
                {0.0, 0.0, 0.3, 0.5},  // F1
                {0.3, 0.5, 0.5, 0.7},  // F2
                {0.5, 0.7, 1.0, 1.0}   // F3
        });
        double[] trajectoryMembership = calculateOverlappingMembership(trajectorySimilarity, new double[][]{
                {0.0, 0.0, 0.3, 0.5},  // F1
                {0.3, 0.5, 0.5, 0.7},  // F2
                {0.5, 0.7, 1.0, 1.0}   // F3
        });

        System.out.println("\n隶属度计算结果：");
        printMembership("信任行为隶属度", trustMembership);
        printMembership("恶意行为隶属度", maliciousMembership);
        printMembership("时空距离隶属度", spatialMembership);
        printMembership("轨迹重合性隶属度", trajectoryMembership);

        // 综合计算实时模糊信任等级
        double[] weights = {0.5, -0.3, 0.4, 0.4}; // 示例权重，恶意行为为负向
        double finalTrustScore = calculateRealTimeTrust(weights, trustMembership, maliciousMembership, spatialMembership, trajectoryMembership);

        System.out.printf("\n车辆实时模糊信任等级 (最终得分 R): %.2f%n", finalTrustScore);
    }

    // 随机生成 [0,1] 范围内的因子值
    private static double generateRandomFactor() {
        Random random = new Random();
        return random.nextDouble(); // 返回 [0,1] 之间的随机值
    }

    // 计算具有重叠交叉的梯形隶属度函数
    private static double[] calculateOverlappingMembership(double value, double[][] trapezoids) {
        int n = trapezoids.length; // 模糊集数量
        double[] membership = new double[n];
        for (int i = 0; i < n; i++) {
            double a = trapezoids[i][0];
            double b = trapezoids[i][1];
            double c = trapezoids[i][2];
            double d = trapezoids[i][3];

            if (value >= a && value < b) {
                membership[i] = (value - a) / (b - a); // 上升阶段
            } else if (value >= b && value <= c) {
                membership[i] = 1.0; // 顶部平台
            } else if (value > c && value <= d) {
                membership[i] = (d - value) / (d - c); // 下降阶段
            } else {
                membership[i] = 0.0; // 超出范围
            }
        }
        return membership;
    }

    // 打印隶属度结果
    private static void printMembership(String label, double[] membership) {
        System.out.print(label + ": ");
        for (int i = 0; i < membership.length; i++) {
            System.out.printf("F%d=%.2f ", i + 1, membership[i]);
        }
        System.out.println();
    }

    // 综合计算实时模糊信任等级
    private static double calculateRealTimeTrust(double[] weights, double[] trustMembership, double[] maliciousMembership, double[] spatialMembership, double[] trajectoryMembership) {
        // 信任行为权重（正向因子）
        double trustScore = calculateWeightedAverage(trustMembership) * weights[0];
        // 恶意行为权重（负向因子，反转）
        double maliciousScore = calculateWeightedAverage(maliciousMembership) * weights[1];
        // 时空距离权重
        double spatialScore = calculateWeightedAverage(spatialMembership) * weights[2];
        // 轨迹重合性权重
        double trajectoryScore = calculateWeightedAverage(trajectoryMembership) * weights[3];

        // 综合得分
        return trustScore + maliciousScore + spatialScore + trajectoryScore;
    }

    // 计算加权平均
    private static double calculateWeightedAverage(double[] membership) {
        double sum = 0.0;
        for (double value : membership) {
            sum += value;
        }
        return sum / membership.length;
    }
}
