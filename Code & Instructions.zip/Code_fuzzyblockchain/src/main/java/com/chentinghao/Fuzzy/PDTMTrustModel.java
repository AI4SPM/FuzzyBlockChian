package com.chentinghao.Fuzzy;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PDTMTrustModel {
    private double trustValue;
    private int successfulInteractions;
    private int unsuccessfulInteractions;
    private static final Random random = new Random();

    public PDTMTrustModel() {
        this.trustValue = 0.5;
        this.successfulInteractions = 0;
        this.unsuccessfulInteractions = 0;
    }

    public void updateTrust(boolean success) {
        if (success) {
            successfulInteractions++;
        } else {
            unsuccessfulInteractions++;
        }
        trustValue = calculateTrustValue();
    }

    private double calculateTrustValue() {
        int totalInteractions = successfulInteractions + unsuccessfulInteractions;

        if (totalInteractions == 0) {
            return 0.5; // 初始信任值
        }

        double successRate = (double) successfulInteractions / totalInteractions;

        // 使用贝叶斯估计平滑成功率，避免极端值
        double smoothedSuccessRate = (successfulInteractions + 1.0) / (totalInteractions + 2.0);

        // 简化后的信任值计算：直接使用平滑后的成功率作为信任值
        return smoothedSuccessRate;
    }

    public double getTrustValue() {
        return trustValue;
    }

    public static TrustResult generateTrustResults() {
        Random random = new Random();

        PDTMTrustModel nodeTrust = new PDTMTrustModel();

            // 1. 随机生成总交互次数 (服从正态分布，均值50，标准差15)
        int totalInteractions = (int) Math.round(random.nextGaussian() * 30 + 50);

            // 确保 totalInteractions 在 0-100 之间
        totalInteractions = Math.max(0, Math.min(100, totalInteractions));

            // 2. 随机生成每次交互的行为 (调用 updateTrust)
        for (int j = 0; j < totalInteractions; j++) {
                boolean success = random.nextDouble() < 0.6; // 随机决定是信任还是恶意行为
                nodeTrust.updateTrust(success);
        }

        double spatialTemporalValue = random.nextDouble();
        double finalTrustScore = nodeTrust.getTrustValue();

        return new TrustResult(finalTrustScore, spatialTemporalValue);
    }
}
