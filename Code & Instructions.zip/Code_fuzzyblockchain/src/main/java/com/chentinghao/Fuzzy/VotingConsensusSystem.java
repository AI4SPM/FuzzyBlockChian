package com.chentinghao.Fuzzy;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.*;

public class VotingConsensusSystem {

    public static void main(String[] args) {
        // 创建共识系统
        VotingConsensusSystem consensusSystem = new VotingConsensusSystem();

        // 添加节点（车辆）
//        consensusSystem.addNodes(100); // 创建 100 个节点

        // 运行共识
        long totalTime = consensusSystem.runConsensus(500); // 运行 100 轮共识
        System.out.printf("100次共识总时间: %.2f秒\n", totalTime / 1000.0);
        System.out.printf("平均每次共识时间: %.2f秒\n", totalTime / 1000.0 / 100);

    }

    // 节点类
    static class Node {
        String id;              // 节点唯一标识
        double trustScore;      // 信任得分
        double spatialTemporalValue;
        public Node(String id) {
            this.id = id;
            // 通过IntuitionisticFuzzyTrustSystem获取信任得分和时空重合度
            TrustResult result = IntuitionisticFuzzyTrustSystem.getTrustScore();
//            TrustResult result = PDTMTrustModel.generateTrustResults();
            this.trustScore = result.getFinalTrustScore();
            this.spatialTemporalValue = result.getSpatialTemporalValue();
        }

        // 随机投票，返回 true 表示赞成票，false 表示反对票
        public boolean vote() {
            double probability = 0;
            // 根据时空重合度值 (spatialTemporalValue) 和 trustScore 调整投票概率
            if (spatialTemporalValue <= 0.33) { // 远
                probability = 0.5;
            } else if (spatialTemporalValue <= 0.66) { // 中
                probability = getVoteProbability(trustScore, "中");
            } else { // 近
                probability = getVoteProbability(trustScore, "近");
            }
            return Math.random() < probability;

        }
        private double getVoteProbability(double trustScore, String spatialTemporal) {
            // 根据 trustScore 的范围调整投票概率
            if (spatialTemporal.equals("近")) {
                if (trustScore < 0.2) {
                    return 0.4;
                } else if (trustScore < 0.4) {
                    return 0.5;
                } else if (trustScore < 0.6) {
                    return 0.6;
                } else if (trustScore < 0.8) {
                    return 0.7;
                } else {
                    return 0.8;
                }
            } else if (spatialTemporal.equals("中")) {
                if (trustScore < 0.2) {
                    return 0.2;
                } else if (trustScore < 0.4) {
                    return 0.3;
                } else if (trustScore < 0.6) {
                    return 0.4;
                } else if (trustScore < 0.8) {
                    return 0.5;
                } else {
                    return 0.6;
                }
            }
            return 0.5;
        }

        // 模拟通信开销
        public void communicate() {
            Random random = new Random();
            int delay = 20 + random.nextInt(101); // 随机延迟20ms到120ms
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // 共识系统类
    private List<Node> nodes = new ArrayList<>();
    private Random random = new Random();

    // 添加节点
    public void addNodes(int count) {
        for (int i = 0; i < count; i++) {
            nodes.add(new Node("Node-" + (i + 1)));
        }
    }

    // 运行共识
    public long runConsensus(int rounds) {

        long startTime = System.currentTimeMillis();
        // 创建线程池，大小根据实际需求调整
        int threadPoolSize = 8; // 与选取的节点数相同
        ExecutorService executor = Executors.newFixedThreadPool(threadPoolSize);
        int correctConsensusCount = 0;

        for (int round = 1; round <= rounds; round++) {
            System.out.printf("第 %d 轮投票:\n", round);
            nodes = generateNodes(100); // 每轮重新生成100个节点

            // 随机选取 6-12 个节点参与投票
            int numVoters = 8;
//            List<Node> selectedNodes = selectRandomNodes(numVoters);
            List<Node> selectedNodes = selectTopTrustedNodes(numVoters);

            // 计算总信任值
            double totalTrustValue = 0.0;
            for (Node node : selectedNodes) {
                totalTrustValue += node.trustScore;
            }

            // 假设共识的真实结果是"正确"
            boolean trueConsensus = true; // 根据实际情况定义真实共识

            // 创建任务列表
            List<Callable<Boolean>> tasks = new ArrayList<>();
            for (Node node : selectedNodes) {
                tasks.add(() -> {
                    node.communicate();
                    return node.vote();
                });
            }
            double agreeTrustValue = 0.0;

            try {
                // 并行执行通信和投票
                List<Future<Boolean>> results = executor.invokeAll(tasks);

                for (int i = 0; i < selectedNodes.size(); i++) {
                    Node node = selectedNodes.get(i);
                    boolean vote = results.get(i).get(); // 获取投票结果
                    if (vote) {
                        agreeTrustValue += node.trustScore;
                    }
                    String spatialTemporalLabel = getSpatialTemporalLabel(node.spatialTemporalValue);

                    System.out.printf("  %s 投票: 信任值=%.2f, 时空重合度=%.2f (%s) -> %s\n",
                            node.id, node.trustScore, node.spatialTemporalValue, spatialTemporalLabel, vote ? "赞成" : "反对");
                }

            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }


            // 判断是否达成共识
            double threshold = totalTrustValue * 0.6; // 60% 阈值
            boolean consensus = agreeTrustValue >= threshold;
            if (consensus == trueConsensus) {
                correctConsensusCount++;
            }
            System.out.printf("投票结果: 总信任值=%.2f, 赞成票信任值=%.2f, 阈值=%.2f -> %s\n\n",
                    totalTrustValue, agreeTrustValue, threshold, consensus ? "达成共识" : "未达成共识");
        }
        executor.shutdown();
        long endTime = System.currentTimeMillis();
        System.out.printf("达成正确共识的次数: %d 次\n", correctConsensusCount);

        return endTime - startTime; // 返回总耗时（毫秒）
    }
    // **关键改动：生成节点列表的方法**
    private List<Node> generateNodes(int count) {
        List<Node> newNodes = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            newNodes.add(new Node("Node-" + (i + 1)));
        }
        return newNodes;
    }


    // 随机选取节点
    private List<Node> selectRandomNodes(int num) {

        List<Node> selected = new ArrayList<>();
        for (int i = 0; i < num; i++) {
            int index = random.nextInt(nodes.size());
            selected.add(nodes.get(index));
        }
        return selected;
    }
    // 选择信任值最高的节点
    private List<Node> selectTopTrustedNodes(int num) {
        // 创建一个新的列表以避免修改原始节点列表
        List<Node> sortedNodes = new ArrayList<>(nodes);

        // 根据trustScore进行降序排序
        sortedNodes.sort((n1, n2) -> Double.compare(n2.trustScore, n1.trustScore));

        // 选择前num个节点
        List<Node> selected = new ArrayList<>();
        for (int i = 0; i < Math.min(num, sortedNodes.size()); i++) {
            selected.add(sortedNodes.get(i));
        }
        return selected;
    }

    private String getSpatialTemporalLabel(double spatialTemporalValue) {
        if (spatialTemporalValue < 0.33) {
            return "远";
        } else if (spatialTemporalValue < 0.66) {
            return "中";
        } else {
            return "近";
        }
    }

}

