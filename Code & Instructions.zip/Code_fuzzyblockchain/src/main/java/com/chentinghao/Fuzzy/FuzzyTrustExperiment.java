package com.chentinghao.Fuzzy;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/9 15:34
 * description:
 */
public class FuzzyTrustExperiment {

    public static void main(String[] args) {
        // 初始化实验参数
        double step = 0.1;
        int steps = (int) (1 / step) + 1;

        // 第一部分实验：恶意行为增加，信任行为固定为1
        System.out.println("实验1: 恶意行为增加，信任行为固定为1");
        for (int i = 0; i < steps; i++) {
            double maliciousBehavior = i * step;
            double trustBehavior = 1.0; // 信任行为固定为1

            // 调用模糊推理系统
            TrustResult result = FuzzyTrustChanges.calculateTrustScore(
                    trustBehavior, maliciousBehavior,
                    0.1, 0.9 // 时空距离和轨迹重合性取固定值
            );

            // 打印结果
            System.out.printf("恶意行为值: %.1f, 信任值: %.2f%n", maliciousBehavior, result.finalTrustScore);
        }

        // 第二部分实验：信任行为减少，恶意行为固定为0
        System.out.println("\n实验2: 信任行为减少，恶意行为固定为0");
        for (int i = 0; i < steps; i++) {
            double trustBehavior = 1.0 - i * step;
            double maliciousBehavior = 0.0; // 恶意行为固定为0

            // 调用模糊推理系统
            TrustResult result = FuzzyTrustChanges.calculateTrustScore(
                    trustBehavior, maliciousBehavior,
                    0.1, 0.9 // 时空距离和轨迹重合性取固定值
            );

            // 打印结果
            System.out.printf("信任行为值: %.1f, 信任值: %.2f%n", trustBehavior, result.finalTrustScore);
        }
    }
}
