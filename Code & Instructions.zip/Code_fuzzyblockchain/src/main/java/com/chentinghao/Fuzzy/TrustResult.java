package com.chentinghao.Fuzzy;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/5 18:11
 * description:
 */
public class TrustResult {
    public double finalTrustScore;        // 信任得分 [0,1]
    public double spatialTemporalValue;   // 时空重合度 [0,1]
    public double finalOnlyTrustScore;

    public TrustResult(double finalTrustScore, double spatialTemporalValue) {
        this.finalTrustScore = finalTrustScore;
        this.spatialTemporalValue = spatialTemporalValue;
    }
    public TrustResult(double finalTrustScore, double spatialTemporalValue,double finalOnlyTrustScore) {
        this.finalTrustScore = finalTrustScore;
        this.spatialTemporalValue = spatialTemporalValue;
        this.finalOnlyTrustScore = finalOnlyTrustScore;
    }

    public double getFinalTrustScore() {
        return finalTrustScore;
    }
    public double getFinalOnlyTrustScore() {
        return finalOnlyTrustScore;
    }

    public double getSpatialTemporalValue() {
        return spatialTemporalValue;
    }
}
