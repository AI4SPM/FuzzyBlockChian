package com.chentinghao.Fuzzy;

import org.apache.commons.math3.distribution.BetaDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math3.stat.correlation.SpearmansCorrelation;

import java.util.Arrays;
import java.util.Random;

public class RandomFactorGenerator {
    private GaussianCopula copula;
    private BetaDistribution similarityDistribution;
    private BetaDistribution distanceDistribution;
    private Random randomGenerator;

    /**
     * 构造函数，初始化Copula和边缘分布。
     *
     * @param correlation        两个变量之间的相关系数（负值表示负相关）
     * @param similarityBetaParams   Beta分布参数 [alpha, beta] 用于轨迹重合性
     * @param distanceBetaParams Beta分布参数 [alpha, beta] 用于时空距离
     */
    public RandomFactorGenerator(double correlation, double[] similarityBetaParams, double[] distanceBetaParams) {
        this.copula = new GaussianCopula(correlation);
        this.similarityDistribution = new BetaDistribution(similarityBetaParams[0], similarityBetaParams[1]);
        this.distanceDistribution = new BetaDistribution(distanceBetaParams[0], distanceBetaParams[1]);
        this.randomGenerator = new Random();
    }

    /**
     * 生成一对随机因子，轨迹重合性和时空距离，均在 [0,1] 范围内，并具有负相关性。
     *
     * @return 包含两个因子的数组，索引0为轨迹重合性，索引1为时空距离
     */
    public double[] generatePair() {
        // 生成一对相关的标准正态变量
        double[][] correlatedNormals = copula.generateCorrelatedNormals(1, randomGenerator);
        double z1 = correlatedNormals[0][0];
        double z2 = correlatedNormals[0][1];

        // 获取标准正态分布对象
        NormalDistribution standardNormal = copula.getStandardNormal();

        // 计算CDF
        double u1 = standardNormal.cumulativeProbability(z1);
        double u2 = standardNormal.cumulativeProbability(z2);

        // 通过边缘分布的逆CDF转换
        double similarity = similarityDistribution.inverseCumulativeProbability(u1);
        double distance = distanceDistribution.inverseCumulativeProbability(u2);

        // 确保在 [0,1] 范围内
        similarity = Math.max(0.0, Math.min(1.0, similarity));
        distance = Math.max(0.0, Math.min(1.0, distance));

        return new double[]{similarity, distance};
    }

    /**
     * 计算并打印生成的因子的相关系数。
     *
     * @param generatedFactors 生成的因子数组
     */
    public void computeAndPrintCorrelation(double[][] generatedFactors) {
        double[] similarities = Arrays.stream(generatedFactors).mapToDouble(a -> a[0]).toArray();
        double[] distances = Arrays.stream(generatedFactors).mapToDouble(a -> a[1]).toArray();

        PearsonsCorrelation pearson = new PearsonsCorrelation();
        double pearsonCorr = pearson.correlation(similarities, distances);
        System.out.printf("Generated Pearson相关系数: %.4f%n", pearsonCorr);

        SpearmansCorrelation spearman = new SpearmansCorrelation();
        double spearmanCorr = spearman.correlation(similarities, distances);
        System.out.printf("Generated Spearman相关系数: %.4f%n", spearmanCorr);
    }

    /**
     * 打印生成的因子数据。
     *
     * @param generatedFactors 生成的因子数组
     * @param count            要打印的因子数量
     */
    public void printGeneratedData(double[][] generatedFactors, int count) {
        System.out.println("Similarity\tDistance");
        for (int i = 0; i < count && i < generatedFactors.length; i++) {
            System.out.printf("%.4f\t\t%.4f%n", generatedFactors[i][0], generatedFactors[i][1]);
        }
    }

    /**
     * 示例主方法，展示如何生成一对随机因子。
     */
    public static void main(String[] args) {
        // 设置相关系数和Beta分布参数
        double correlation = -0.4; // 更强的负相关性
        double[] similarityBetaParams = {4.0, 3.0}; // 增加Alpha，减少Beta以更集中相似性于高值
        double[] distanceBetaParams = {3.0, 4.0}; // 调整参数以适应需求

        RandomFactorGenerator generator = new RandomFactorGenerator(correlation, similarityBetaParams, distanceBetaParams);

        // 生成并打印10对随机因子
        int nSamples = 10;
        double[][] generatedFactors = new double[nSamples][2];
        for (int i = 0; i < nSamples; i++) {
            generatedFactors[i] = generator.generatePair();
        }

        // 打印生成的数据
        generator.printGeneratedData(generatedFactors, nSamples);

        // 计算并打印相关系数
        generator.computeAndPrintCorrelation(generatedFactors);
    }
}
