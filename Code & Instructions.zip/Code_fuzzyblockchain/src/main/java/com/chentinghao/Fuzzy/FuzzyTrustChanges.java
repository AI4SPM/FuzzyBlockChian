package com.chentinghao.Fuzzy;

import java.util.Random;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/9 15:24
 * description:
 */
public class FuzzyTrustChanges {

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/2 15:51
 * description:
 */

        private static final Random random = new Random(123);
        private static final double correlation = -0.6; // 更强的负相关性
        private static final double[] betaParams = {3.0, 4.0}; // 增加Alpha，减少Beta以集中相似性于高值
        private static final double[] similarityBetaParams = {4.0, 3.0}; // 增加Alpha，减少Beta以更集中相似性于高值
        private static final double[] distanceBetaParams = {3.0, 4.0}; // 调整参数以适应需求

//    private static final PoissonDistribution poisson = new PoissonDistribution(2.0); // λ=2

        public static TrustResult getTrustScore() {
            // 直接调用已有模糊信任计算逻辑
            double trustBehavior = generateRandomFactor();
            double maliciousBehavior = generateRandomFactor();
//        double spatialDistance = normalizePoisson(generatePoisson(POISSON_LAMBDA));
//        double trajectorySimilarity = normalizePoisson(generatePoisson(POISSON_LAMBDA));
            RandomFactorGenerator generator = new RandomFactorGenerator(correlation, similarityBetaParams,distanceBetaParams);
            double[][] generatedFactors = new double[1][2];
            generatedFactors[0] = generator.generatePair();
            double trajectorySimilarity = generatedFactors[0][0];
            double spatialDistance = generatedFactors[0][1];

            System.out.println("随机生成的因子值（均在[0,1]范围内）：");
            System.out.printf("信任行为: %.2f%n", trustBehavior);
            System.out.printf("恶意行为: %.2f%n", maliciousBehavior);
            System.out.printf("时空距离: %.2f%n", spatialDistance);
            System.out.printf("轨迹重合性: %.2f%n", trajectorySimilarity);

//        double spatialDistance = generateRandomFactor();
//        double trajectorySimilarity = generateRandomFactor();
//        TrustResult finalTrustScore = calculateTrustScore(trustBehavior, maliciousBehavior, spatialDistance, trajectorySimilarity);
//        double trustLevel = getTrustLevel(finalTrustScore);
            return calculateTrustScore(trustBehavior, maliciousBehavior, spatialDistance, trajectorySimilarity);

        }

        public static TrustResult  calculateTrustScore(double trustBehavior, double maliciousBehavior, double spatialDistance, double trajectorySimilarity) {
            // 随机生成输入因子值（均在[0,1]范围内）
//        double trustBehavior = generateRandomFactor();
//        double maliciousBehavior = generateRandomFactor();
//        double spatialDistance = generateRandomFactor();
//        double trajectorySimilarity = generateRandomFactor();

            // 隶属度、非隶属度与犹豫度计算（梯形隶属度带重叠）
            MembershipDegree[] trustMembership = calculateOverlappingMembership(trustBehavior, new double[][]{
//                    {0.0, 0.0, 0.2, 0.4},  // F1
//                    {0.2, 0.4, 0.4, 0.6},  // F2
//                    {0.4, 0.6, 0.6, 0.8},  // F3
//                    {0.6, 0.8, 0.8, 1.0},  // F4
//                    {0.8, 1.0, 1.0, 1.0}   // F5

                    {0.0, 0.0, 0.1, 0.3},  // F1
                    {0.1, 0.3, 0.35, 0.5},  // F2
                    {0.35, 0.58, 0.63, 0.68},  // F3
                    {0.5, 0.7, 0.7, 0.9},  // F4
                    {0.7, 1.0, 1.0, 1.0}   // F5
            });

            MembershipDegree[] maliciousMembership = calculateOverlappingMembership(maliciousBehavior, new double[][]{
//                    {0.0, 0.0, 0.2, 0.4},  // F1
//                    {0.2, 0.4, 0.4, 0.6},  // F2
//                    {0.4, 0.6, 0.6, 0.8},  // F3
//                    {0.6, 0.8, 0.8, 1.0},  // F4
//                    {0.8, 1.0, 1.0, 1.0}   // F5

                    {0.0, 0.0, 0.1, 0.3},  // F1
                    {0.1, 0.3, 0.35, 0.5},  // F2
                    {0.35, 0.58, 0.63, 0.68},  // F3
                    {0.47, 0.7, 0.7, 0.9},  // F4
                    {0.6, 1.0, 1.0, 1.0}   // F5
            });

            MembershipDegree[] spatialMembership = calculateOverlappingMembership(spatialDistance, new double[][]{
                    {0.0, 0.0, 0.3, 0.5},  // S1
                    {0.3, 0.5, 0.5, 0.7},  // S2
                    {0.5, 0.7, 1.0, 1.0}   // S3
            });

            MembershipDegree[] trajectoryMembership = calculateOverlappingMembership(trajectorySimilarity, new double[][]{
                    {0.0, 0.0, 0.3, 0.5},  // G1
                    {0.3, 0.5, 0.5, 0.7},  // G2
                    {0.5, 0.7, 1.0, 1.0}   // G3
            });

//            System.out.println("\n隶属度、非隶属度与犹豫度计算结果：");
//            printMembership("信任行为隶属度", trustMembership);
//            printMembership("恶意行为隶属度", maliciousMembership);
//            printMembership("时空距离隶属度", spatialMembership);
//            printMembership("轨迹重合性隶属度", trajectoryMembership);

            // 规则评估和聚合
            IntuitionisticFuzzySet[] O = evaluateTable3(trustMembership, maliciousMembership);
            IntuitionisticFuzzySet[] S = evaluateTable5(trajectoryMembership, spatialMembership);
            IntuitionisticFuzzySet[] FR = evaluateTable6(O, S);

//            System.out.println("\n规则评估结果（隶属度, 非隶属度, 犹豫度）：");
//            printIntuitionisticFuzzySet("客观模糊信任等级 O", O);
//            printIntuitionisticFuzzySet("时空重合性 S", S);
//            printIntuitionisticFuzzySet("实时模糊信任等级 FR", FR);

            // 去模糊化，计算最终信任等级
//            double finalOnlyTrustScore = defuzzify(O, new double[]{0.0, 0.25, 0.5, 0.75, 1.0});

            double spatialTemporalValue = defuzzify(S, new double[]{0.0, 0.3, 0.6, 1.0});
            double finalTrustScore = defuzzify(O, new double[]{0.0, 0.25, 0.5, 0.75, 1.0});

            return new TrustResult(finalTrustScore, spatialTemporalValue);
//        String trustLevel = getTrustLevel(finalTrustScore); // 获取对应的信任等级
//
//        System.out.printf("\n车辆实时模糊信任等级 (最终得分 FR): %.2f, 等级: %s%n", finalTrustScore, trustLevel);
        }

        static double getTrustLevel(double score) {
            if (score < 0.2) {
//            return "FR1 (非常低)";
                return 1;
            } else if (score < 0.4) {
//            return "FR2 (较低)";
                return 2;
            } else if (score < 0.6) {
//            return "FR3 (中等)";
                return 3;
            } else if (score < 0.8) {
//            return "FR4 (较高)";
                return 4;
            } else {
//            return "FR5 (非常高)";
                return 5;
            }
        }

        // 随机生成 [0,1] 范围内的因子值
        private static double generateRandomFactor() {
//        Random random = new Random();
            return random.nextDouble(); // 返回 [0,1] 之间的随机值
        }

        // 隶属度、非隶属度与犹豫度的计算（梯形隶属度带重叠）
        private static MembershipDegree[] calculateOverlappingMembership(double value, double[][] trapezoids) {
            int n = trapezoids.length; // 模糊集数量
            MembershipDegree[] membership = new MembershipDegree[n];
            for (int i = 0; i < n; i++) {
                double a = trapezoids[i][0];
                double b = trapezoids[i][1];
                double c = trapezoids[i][2];
                double d = trapezoids[i][3];

                double mu = 0.0;
                if (value >= a && value < b) {
                    mu = (value - a) / (b - a); // 上升阶段
                } else if (value >= b && value <= c) {
                    mu = 1.0; // 顶部平台
                } else if (value > c && value <= d) {
                    mu = (d - value) / (d - c); // 下降阶段
                }

                double nu = 0.0;
                if (value >= a && value < b) {
                    nu = 1 - mu; // 对称下降
                } else if (value >= b && value <= c) {
                    nu = 0.0; // 非隶属度最低
                } else if (value > c && value <= d) {
                    nu = 1 - mu; // 对称上升
                } else {
                    nu = 1.0; // 超出范围，完全非隶属
                }

                double pi = 0.0;
                if (mu < 0.9) {
                    pi = 1 - mu - nu;
                    if (pi < 0) {
                        pi = 0.0; // 确保 pi 不为负
                    }
                }

//            // 确保 mu + nu + pi <= 1
//            if (mu + nu + pi > 1.0) {
//                double sum = mu + nu + pi;
//                mu /= sum;
//                nu /= sum;
//                pi /= sum;
//            }

                membership[i] = new MembershipDegree(mu, nu, pi);
            }
            return membership;
        }

        // 打印隶属度、非隶属度与犹豫度结果
        private static void printMembership(String label, MembershipDegree[] membership) {
            System.out.print(label + ": ");
            for (int i = 0; i < membership.length; i++) {
                System.out.printf("F%d=(μ=%.2f, ν=%.2f, π=%.2f) ", i + 1, membership[i].mu, membership[i].nu, membership[i].pi);
            }
            System.out.println();
        }

        // 打印直觉模糊集
//    private static void printIntuitionisticFuzzySet(String label, IntuitionisticFuzzySet[] set) {
//        System.out.print(label + ": ");
//        for (int i = 0; i < set.length; i++) {
//            System.out.printf("FR%d=(μ=%.2f, ν=%.2f, π=%.2f) ", i + 1, set[i].mu, set[i].nu, set[i].pi);
//        }
//        System.out.println();
//    }
        private static void printIntuitionisticFuzzySet(String label, IntuitionisticFuzzySet[] set) {
            System.out.print(label + ": ");
            String prefix;
            if (label.contains("O")) {
                prefix = "O";
            } else if (label.contains("S")) {
                prefix = "S";
            } else if (label.contains("FR")) {
                prefix = "FR";
            } else {
                prefix = "FR"; // 默认前缀
            }
            for (int i = 0; i < set.length; i++) {
                System.out.printf("%s%d=(μ=%.2f, ν=%.2f, π=%.2f) ", prefix, i + 1, set[i].mu, set[i].nu, set[i].pi);
            }
            System.out.println();
        }

        // 评估表三：信任行为和恶意行为 → 客观模糊信任等级 O
        private static IntuitionisticFuzzySet[] evaluateTable3(MembershipDegree[] trustMembership, MembershipDegree[] maliciousMembership) {
            int oLevels = 5; // O1 to O5
            IntuitionisticFuzzySet[] O = new IntuitionisticFuzzySet[oLevels];

            // 定义表三的规则映射
            int[][] table3Rules = {
                    {1, 1, 0, 0, 0}, // F1
                    {2, 2, 1, 0, 0}, // F2
                    {3, 2, 2, 1, 0}, // F3
                    {3, 3, 2, 1, 1}, // F4
                    {4, 3, 2, 1, 1}  // F5
            };

            // 初始化 O
            for (int o = 0; o < oLevels; o++) {
                O[o] = new IntuitionisticFuzzySet(0.0, 1.0, 0.0); // 初始值，π暂时设为0
            }

            for (int i = 0; i < trustMembership.length; i++) {
                for (int j = 0; j < maliciousMembership.length; j++) {
                    int oIndex = table3Rules[i][j];

                    if (trustMembership[i].mu <=0 || maliciousMembership[j].mu <= 0) {
                        continue; // 忽略低激活度的规则
                    }

                    double activationMu = Math.min(trustMembership[i].mu, maliciousMembership[j].mu);
                    double activationNu = Math.max(trustMembership[i].nu, maliciousMembership[j].nu);
                    double activationPi = Math.min(trustMembership[i].pi, maliciousMembership[j].pi); // 根据需要定义 π 的合成方式

                    System.out.printf("规则激活: 信任F%d & 恶意F%d -> O%d (μ=%.2f, ν=%.2f, π=%.2f)%n",
                            i + 1, j + 1, oIndex + 1, activationMu, activationNu, activationPi);


                    // 更新 O[oIndex] 的 μ 和 ν
                    O[oIndex].mu = Math.max(O[oIndex].mu, activationMu);
                    O[oIndex].nu = Math.min(O[oIndex].nu, activationNu);

                    // 更新 π，仅在 μ < 0.9 时加入
                    if (activationMu < 0.9) {
                        O[oIndex].pi = Math.max(O[oIndex].pi, activationPi);
                    }
                }
            }

            return O;
        }

        // 评估表五：轨迹聚合相似性和时空距离 → 时空重合性 S
        static IntuitionisticFuzzySet[] evaluateTable5(MembershipDegree[] trajectoryMembership, MembershipDegree[] spatialMembership) {
            int sLevels = 3; // S1 to S3
            IntuitionisticFuzzySet[] S = new IntuitionisticFuzzySet[sLevels];

            // 定义表五的规则映射
            int[][] table5Rules = {
                    {1, 0, 0},// G1
                    {2, 1, 0},// G2
                    {2, 2, 1} // G3
            };

            // 初始化 S
            for (int s = 0; s < sLevels; s++) {
                S[s] = new IntuitionisticFuzzySet(0.0, 1.0, 0.0); // 初始值，π暂时设为0
            }

            for (int i = 0; i < trajectoryMembership.length; i++) {
                for (int j = 0; j < spatialMembership.length; j++) {
                    int sIndex = table5Rules[i][j];
                    if (trajectoryMembership[i].mu <=0 || spatialMembership[j].mu <= 0) {
                        continue; // 忽略低激活度的规则
                    }

                    double activationMu = Math.min(trajectoryMembership[i].mu, spatialMembership[j].mu);
                    double activationNu = Math.max(trajectoryMembership[i].nu, spatialMembership[j].nu);
                    double activationPi = Math.min(trajectoryMembership[i].pi, spatialMembership[j].pi); // 根据需要定义 π 的合成方式

                    System.out.printf("规则激活: 时空距离S%d & 轨迹相似性G%d -> S%d (μ=%.2f, ν=%.2f, π=%.2f)%n",
                            i + 1, j + 1, sIndex + 1, activationMu, activationNu, activationPi);

                    // 更新 S[sIndex] 的 μ 和 ν
                    S[sIndex].mu = Math.max(S[sIndex].mu, activationMu);
                    S[sIndex].nu = Math.min(S[sIndex].nu, activationNu);

                    // 更新 π，仅在 μ < 0.9 时加入
                    if (activationMu < 0.9) {
                        S[sIndex].pi = Math.max(S[sIndex].pi, activationPi);
                    }
                }
            }

            return S;
        }

        // 评估表六：时空重合性 S 和 客观模糊信任等级 O → 实时模糊信任等级 FR
        private static IntuitionisticFuzzySet[] evaluateTable6(IntuitionisticFuzzySet[] O, IntuitionisticFuzzySet[] S) {
            int frLevels = 5; // FR1 to FR5
            IntuitionisticFuzzySet[] FR = new IntuitionisticFuzzySet[frLevels];

            // 定义表六的规则映射
            int[][] table6Rules = {
                    {0, 0, 1, 2, 3}, // S1 与 O1~O5
                    {0, 1, 2, 3, 3}, // S2 与 O1~O5
                    {1, 2, 3, 3, 4}  // S3 与 O1~O5
            };

            // 初始化 FR
            for (int fr = 0; fr < frLevels; fr++) {
                FR[fr] = new IntuitionisticFuzzySet(0.0, 1.0, 0.0); // 初始值，π暂时设为0
            }

            for (int i = 0; i < S.length; i++) {
                for (int j = 0; j < O.length; j++) {
                    int frIndex = table6Rules[i][j];
                    double activationMu = Math.min(S[i].mu, O[j].mu);
                    double activationNu = Math.max(S[i].nu, O[j].nu);
                    double activationPi = Math.min(S[i].pi, O[j].pi); // 根据需要定义 π 的合成方式

                    // 更新 FR[frIndex] 的 μ 和 ν
                    FR[frIndex].mu = Math.max(FR[frIndex].mu, activationMu);
                    FR[frIndex].nu = Math.min(FR[frIndex].nu, activationNu);

                    // 更新 π，仅在 μ < 0.9 时加入
                    if (activationMu < 0.9) {
                        FR[frIndex].pi = Math.max(FR[frIndex].pi, activationPi);
                    }
                }
            }

            return FR;
        }

        // 去模糊化（综合考虑隶属度和犹豫度）
        private static double defuzzify(IntuitionisticFuzzySet[] membership, double[] universe) {
            double numerator = 0.0;
            double denominator = 0.0;
            for (int i = 0; i < membership.length; i++) {
                double pi = membership[i].pi;
                // 赋予犹豫度一定的权重，这里假设与 μ 同等重要
                numerator += (membership[i].mu + pi) * universe[i];
                denominator += (membership[i].mu + pi);
            }
            if (denominator == 0) {
                return 0; // 避免除以零
            }
            return numerator / denominator;
        }


}
