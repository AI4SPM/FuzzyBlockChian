package com.chentinghao.Fuzzy;

/**
 * @author ChenTinghao
 * @Description TODO
 * @package com.chentinghao.Fuzzy
 * @Created 2025/3/4
 */
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * @author ChenTinghao
 * @Description 修改后：使用 finalOnlyTrustScore 动态调整恶意概率
 * 当 finalOnlyTrustScore < 0.3 时，固定因子为 1.0
 * 当 finalOnlyTrustScore < 0.66 时，固定因子为 0.6
 * 当 finalOnlyTrustScore >= 0.66 时，固定因子为 0.3
 * 最终恶意概率 = baseMaliciousRatio * 固定因子
 * @Created 2025/3/4
 */
public class VotingDefendDynmicConsensus {

    public static void main(String[] args) {
        // 创建共识系统
        VotingDefendDynmicConsensus consensusSystem = new VotingDefendDynmicConsensus();
        long totalTime = consensusSystem.runConsensus(500); // 运行 500 次共识
        System.out.printf("500次共识总时间: %.2f秒\n", totalTime / 1000.0);
        System.out.printf("平均每次共识时间: %.2f秒\n", totalTime / 1000.0 / 500);
    }

    // 节点类
    static class Node {
        String id;
        double trustScore;
        double spatialTemporalValue;
        boolean isMalicious;
        double finalOnlyTrustScore;

        /**
         * 构造函数中传入系统基础恶意比率（例如 0.3）
         */
        public Node(String id, double baseMaliciousRatio) {
            this.id = id;
            TrustResult result = IntuitionisticFuzzyTrustSystem.getTrustScore();
            this.finalOnlyTrustScore = result.getFinalOnlyTrustScore();
            this.trustScore = result.getFinalTrustScore();
            this.spatialTemporalValue = result.getSpatialTemporalValue();
            // 根据 finalOnlyTrustScore 计算固定因子，然后得到最终恶意概率
            double factor = getMaliciousFactor(finalOnlyTrustScore);
            double effectiveMaliciousProbability = baseMaliciousRatio * factor;
            this.isMalicious = Math.random() < effectiveMaliciousProbability;
        }

        // 根据 finalOnlyTrustScore 返回对应的固定因子
        private double getMaliciousFactor(double score) {
            if (score < 0.3) {
                return 1.0;
            } else if (score < 0.66) {
                return 0.6;
            } else {
                return 0.3;
            }
        }

        public boolean vote() {
            double probability = 0;
            if (spatialTemporalValue <= 0.33) {
                probability = 0.5;
            } else if (spatialTemporalValue <= 0.66) {
                probability = getVoteProbability(trustScore, "中");
            } else {
                probability = getVoteProbability(trustScore, "近");
            }
            boolean computedVote = Math.random() < probability;
            // 恶意节点取反投票
            return isMalicious ? !computedVote : computedVote;
        }

        private double getVoteProbability(double trustScore, String spatialTemporal) {
            if (spatialTemporal.equals("近")) {
                if (trustScore < 0.2) return 0.4;
                else if (trustScore < 0.4) return 0.5;
                else if (trustScore < 0.6) return 0.6;
                else if (trustScore < 0.8) return 0.7;
                else return 0.8;
            } else if (spatialTemporal.equals("中")) {
                if (trustScore < 0.2) return 0.2;
                else if (trustScore < 0.4) return 0.3;
                else if (trustScore < 0.6) return 0.4;
                else if (trustScore < 0.8) return 0.5;
                else return 0.6;
            }
            return 0.5;
        }

        public void communicate() {
            int delay = 20 + (int)(Math.random() * 101); // 延时 20ms ~ 120ms
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private List<Node> nodes = new ArrayList<>();

    /**
     * 生成节点时传入基础恶意比率，由节点内部根据 finalOnlyTrustScore 调整
     */
    private List<Node> generateNodes(int count, double baseMaliciousRatio) {
        List<Node> newNodes = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            newNodes.add(new Node("Node-" + (i + 1), baseMaliciousRatio));
        }
        return newNodes;
    }

    // 从当前节点列表中选取信任值最高的若干节点参与共识
    private List<Node> selectTopTrustedNodes(int num) {
        List<Node> sortedNodes = new ArrayList<>(nodes);
        sortedNodes.sort((n1, n2) -> Double.compare(n2.trustScore, n1.trustScore));
        return sortedNodes.subList(0, Math.min(num, sortedNodes.size()));
    }

    private String getSpatialTemporalLabel(double spatialTemporalValue) {
        if (spatialTemporalValue < 0.33) return "远";
        else if (spatialTemporalValue < 0.66) return "中";
        else return "近";
    }

    public long runConsensus(int rounds) {
        long startTime = System.currentTimeMillis();
        ExecutorService executor = Executors.newFixedThreadPool(8);

        // 统计各轮次数据
        int totalFakeRounds = 0;       // 伪造数据轮总数
        int totalLegitRounds = 0;      // 合法数据轮总数
        int fakeDetectionCount = 0;    // 伪造数据轮中正确检测（共识结果为 false）的次数
        int legitDetectionCount = 0;   // 合法数据轮中正确检测（共识结果为 true）的次数
        int fakeMisjudgementCount = 0;  // 伪造数据轮中误判（共识结果为 true）的次数
        int legitMisjudgementCount = 0; // 合法数据轮中误判（共识结果为 false）的次数

        // 定义系统基础恶意比率（例如 0.3）
        double baseMaliciousRatio = 0.3;

        for (int round = 1; round <= rounds; round++) {
            System.out.printf("第 %d 轮共识:\n", round);
            // 随机决定本轮数据类型：30% 轮次为伪造数据轮，70% 为合法数据轮
            boolean isFakeRound = Math.random() < 0.3;
            boolean trueConsensus; // 伪造数据轮真实结果为 false，合法数据轮真实结果为 true
            if (isFakeRound) {
                trueConsensus = false;
                totalFakeRounds++;
            } else {
                trueConsensus = true;
                totalLegitRounds++;
            }
            // 生成节点（每轮生成 100 个节点，每个节点内部根据 finalOnlyTrustScore 动态计算恶意概率）
            nodes = generateNodes(100, baseMaliciousRatio);
            // 选取参与共识的节点（例如选取信任值最高的 8 个）
            int numVoters = 8;
            List<Node> selectedNodes = selectTopTrustedNodes(numVoters);

            // 计算选取节点的总信任值
            double totalTrustValue = 0.0;
            for (Node node : selectedNodes) {
                totalTrustValue += node.trustScore;
            }

            // 创建任务，让每个节点进行投票
            List<Callable<Boolean>> tasks = new ArrayList<>();
            for (Node node : selectedNodes) {
                tasks.add(() -> {
                    node.communicate();
                    return node.vote();
                });
            }
            double agreeTrustValue = 0.0;
            try {
                List<Future<Boolean>> results = executor.invokeAll(tasks);
                for (int i = 0; i < selectedNodes.size(); i++) {
                    Node node = selectedNodes.get(i);
                    boolean vote = results.get(i).get();
                    if (vote) {
                        agreeTrustValue += node.trustScore;
                    }
                    String label = getSpatialTemporalLabel(node.spatialTemporalValue);
                    System.out.printf("  %s 投票: 信任值=%.2f, 时空重合度=%.2f(%s), 恶意=%s -> %s\n",
                            node.id, node.trustScore, node.spatialTemporalValue, label,
                            node.isMalicious ? "是" : "否", vote ? "赞成" : "反对");
                }
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }

            // 根据设定阈值决定本轮共识结果（60% 的总信任值作为阈值）
            double threshold = totalTrustValue * 0.6;
            boolean consensusResult = agreeTrustValue >= threshold;
            System.out.printf("  本轮: 总信任值=%.2f, 赞成信任值=%.2f, 阈值=%.2f -> 共识结果: %s, 真实结果: %s\n\n",
                    totalTrustValue, agreeTrustValue, threshold,
                    consensusResult ? "true" : "false",
                    trueConsensus ? "true" : "false");

            // 按轮次统计检测和误判
            if (isFakeRound) {
                if (!consensusResult) {
                    fakeDetectionCount++;
                } else {
                    fakeMisjudgementCount++;
                }
            } else {
                if (consensusResult) {
                    legitDetectionCount++;
                } else {
                    legitMisjudgementCount++;
                }
            }
        }

        // 输出基于共识轮次的统计指标
        System.out.printf("伪造数据检测率: %.2f%%\n", totalFakeRounds == 0 ? 0 : (fakeDetectionCount / (double) totalFakeRounds) * 100);
        System.out.printf("合法数据检测率: %.2f%%\n", totalLegitRounds == 0 ? 0 : (legitDetectionCount / (double) totalLegitRounds) * 100);
        System.out.printf("伪造数据误判率: %.2f%%\n", totalFakeRounds == 0 ? 0 : (fakeMisjudgementCount / (double) totalFakeRounds) * 100);
        System.out.printf("合法数据误判率: %.2f%%\n", totalLegitRounds == 0 ? 0 : (legitMisjudgementCount / (double) totalLegitRounds) * 100);

        executor.shutdown();
        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }
}
