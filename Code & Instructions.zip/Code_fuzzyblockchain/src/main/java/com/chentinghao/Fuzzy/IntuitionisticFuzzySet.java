package com.chentinghao.Fuzzy;

/**
 * @Auther Chen Tinghao
 * @Date 2025/1/2 15:57
 * description:
 */
class IntuitionisticFuzzySet {
    double mu; // 隶属度
    double nu; // 非隶属度
    double pi; // 犹豫度

    IntuitionisticFuzzySet(double mu, double nu, double pi) {
        this.mu = mu;
        this.nu = nu;
        this.pi = pi;
    }
}
