package com.chentinghao.DPoS;

import java.util.Random;

/**
 * @author ChenTinghao
 * @Description TODO
 * @package com.chentinghao.DPoS
 * @Created 2025/3/2
 */
class Node {
    int id;              // 节点ID
    int votes;           // 获得票数
    boolean isWitness;   // 是否为见证人
    int blocksProduced;  // 成功出块次数
    int failures;        // 出块失败次数

    public Node(int id) {
        this.id = id;
        this.votes = new Random().nextInt(100); // 随机分配初始票数
        this.isWitness = false;
        this.blocksProduced = 0;
        this.failures = 0;
    }
}

