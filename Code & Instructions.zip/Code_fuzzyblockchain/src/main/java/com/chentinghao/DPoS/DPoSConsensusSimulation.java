import java.util.*;
import java.util.concurrent.*;
import java.util.stream.IntStream;

public class DPoSConsensusSimulation {

    // 模拟网络延迟（20ms到120ms之间）
    private static final Random random = new Random();
    private static final int NUM_NODES = 10; // 节点数量
    private static final int NUM_ITERATIONS = 100; // 执行共识的轮次

    // 模拟通信延迟（20ms到120ms之间）
    private static long getRandomDelay() {
        return 20 + random.nextInt(101); // 返回20到120之间的延迟
    }

    // 模拟选举过程，返回选举的时间
    private static long performElection() {
        // 假设选举时间在50ms到150ms之间
        return 50 + random.nextInt(101);
    }

    // 执行一次共识过程，返回本次共识所需的时间（包括选举时间）
    private static long performConsensusRound(int round) {
        // 执行选举过程，计算选举时间
        long electionTime = performElection();

        // 模拟每个节点的通信延迟
        List<Long> delays = new ArrayList<>();
        for (int i = 0; i < NUM_NODES; i++) {
            delays.add(getRandomDelay());
        }

        // 假设共识是并行的，最慢的节点决定共识时间
        long maxDelay = Collections.max(delays);

        // 返回总共识时间：选举时间 + 最慢节点的通信延迟
        long totalConsensusTime = electionTime + maxDelay;
        System.out.println("Round " + round + ": Election time = " + electionTime + " ms, Consensus time = " + maxDelay + " ms, Total time = " + totalConsensusTime + " ms");

        return totalConsensusTime;
    }

    // 执行多个共识轮次并计算总时间
    public static long runConsensusSimulation() throws InterruptedException, ExecutionException {
        ExecutorService executorService = Executors.newFixedThreadPool(NUM_NODES); // 使用线程池并行执行共识
        List<Callable<Long>> tasks = new ArrayList<>();

        // 创建并行任务
        for (int i = 0; i < NUM_ITERATIONS; i++) {
            int round = i + 1;
            tasks.add(() -> performConsensusRound(round));
        }

        // 执行任务并获取结果
        List<Future<Long>> results = executorService.invokeAll(tasks);
        executorService.shutdown();

        // 计算总共识时间
        long totalConsensusTime = 0;
        for (Future<Long> result : results) {
            totalConsensusTime += result.get();
        }

        return totalConsensusTime;
    }

    public static void main(String[] args) {
        try {
            long totalConsensusTime = runConsensusSimulation();
            System.out.println("Total consensus time for 100 rounds (including election time): " + totalConsensusTime + " ms");
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
