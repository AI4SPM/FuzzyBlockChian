package com.chentinghao.PBFT;

/**
 * @author ChenTinghao
 * @Description TODO
 * @package com.chentinghao.PBFT
 * @Created 2025/3/2
 */
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.IntStream;

public class PBFTConsensusSimulation {

    // 模拟网络延迟（20ms到120ms之间）
    private static final Random random = new Random();
    private static final int NUM_NODES = 10; // 总节点数
    private static final int FAULTY_NODES = 3; // 可能的拜占庭节点（PBFT要求f = (N-1)/3）
    private static final int NUM_ITERATIONS = 100; // 执行共识的轮次

    // 获取随机通信延迟（20ms到120ms之间）
    private static long getRandomDelay() {
        return 20 + random.nextInt(101);
    }

    // 执行PBFT共识的各个阶段，并返回该轮共识的时间
    private static long performPBFTConsensusRound(int round) {
        // 各阶段的通信延迟
        long prePrepareTime = getRandomDelay();  // 预准备阶段
        long prepareTime = getRandomDelay();     // 准备阶段
        long commitTime = getRandomDelay();      // 提交阶段
        long executeTime = getRandomDelay();     // 执行阶段

        // PBFT的最终共识时间由所有阶段的时间累加
        long totalConsensusTime = prePrepareTime + prepareTime + commitTime + executeTime;
        System.out.println("Round " + round + ": PrePrepare = " + prePrepareTime + " ms, Prepare = "
                + prepareTime + " ms, Commit = " + commitTime + " ms, Execute = "
                + executeTime + " ms, Total = " + totalConsensusTime + " ms");

        return totalConsensusTime;
    }

    // 执行多个PBFT共识轮次并计算总时间
    public static long runPBFTConsensusSimulation() throws InterruptedException, ExecutionException {
        ExecutorService executorService = Executors.newFixedThreadPool(NUM_NODES); // 并行线程池
        List<Callable<Long>> tasks = new ArrayList<>();

        // 创建共识任务
        for (int i = 0; i < NUM_ITERATIONS; i++) {
            int round = i + 1;
            tasks.add(() -> performPBFTConsensusRound(round));
        }

        // 并行执行任务并获取结果
        List<Future<Long>> results = executorService.invokeAll(tasks);
        executorService.shutdown();

        // 计算总共识时间
        long totalConsensusTime = 0;
        for (Future<Long> result : results) {
            totalConsensusTime += result.get();
        }

        return totalConsensusTime;
    }

    public static void main(String[] args) {
        try {
            long totalConsensusTime = runPBFTConsensusSimulation();
            System.out.println("Total consensus time for 100 rounds (PBFT): " + totalConsensusTime + " ms");
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
